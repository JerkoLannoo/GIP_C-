﻿namespace SocketIO.Core
{
    public enum EngineIO
    {
        V3 = 3,
        V4 = 4
    }
}
