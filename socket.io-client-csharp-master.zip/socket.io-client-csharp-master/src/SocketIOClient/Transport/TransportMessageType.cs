﻿namespace SocketIOClient.Transport
{
    public enum TransportMessageType
    {
        Text,
        Binary,
        Close
    }
}
