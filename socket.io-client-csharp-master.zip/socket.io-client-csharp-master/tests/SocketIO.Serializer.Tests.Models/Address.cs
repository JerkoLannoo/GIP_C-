namespace SocketIO.Serializer.Tests.Models;

public class Address
{
    public string Planet { get; set; } = null!;
}