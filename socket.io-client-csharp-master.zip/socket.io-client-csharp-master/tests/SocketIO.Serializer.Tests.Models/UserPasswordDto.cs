namespace SocketIO.Serializer.Tests.Models;

public class UserPasswordDto
{
    public string User { get; set; } = null!;
    public string Password { get; set; } = null!;
}